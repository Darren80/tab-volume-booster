// Tab Volume Booster - content script
// Routes every <video>/<audio> element on the page through a Web Audio graph:
//   source -> bassFilter (lowshelf) -> voiceFilter (peaking) -> masterGain -> destination
// The graph is only engaged the first time the user actually changes the volume
// or picks a preset, so pages sound completely native until then. (Routing a
// suspended AudioContext would otherwise mute the page.)

(() => {
  // Injected on demand every time the popup opens; only set up once per page.
  if (window.__tabVolumeBoosterInjected) return;
  window.__tabVolumeBoosterInjected = true;

  const api = typeof browser !== "undefined" ? browser : chrome;

  let audioContext = null;
  let masterGain = null;
  let bassFilter = null;
  let voiceFilter = null;
  let observer = null;

  const wiredElements = new WeakSet(); // media elements already routed through the graph
  let currentVolume = 1.0; // gain multiplier: 1.0 == 100%
  let currentPreset = "default";
  let engaged = false; // whether we've taken over the page audio yet

  function ensureContext() {
    if (audioContext) return;

    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    audioContext = new AudioContextClass();

    bassFilter = audioContext.createBiquadFilter();
    bassFilter.type = "lowshelf";
    bassFilter.frequency.value = 200;
    bassFilter.gain.value = 0;

    voiceFilter = audioContext.createBiquadFilter();
    voiceFilter.type = "peaking";
    voiceFilter.frequency.value = 2500;
    voiceFilter.Q.value = 1;
    voiceFilter.gain.value = 0;

    masterGain = audioContext.createGain();
    masterGain.gain.value = currentVolume;

    bassFilter.connect(voiceFilter);
    voiceFilter.connect(masterGain);
    masterGain.connect(audioContext.destination);
  }

  function wireElement(element) {
    if (wiredElements.has(element)) return;
    try {
      // createMediaElementSource can only be called once per element, ever.
      const source = audioContext.createMediaElementSource(element);
      source.connect(bassFilter);
      wiredElements.add(element);
    } catch (err) {
      // Already routed elsewhere, or a cross-origin element we can't touch.
    }
  }

  function startObserving() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (!(node instanceof HTMLElement)) return;
          if (node.matches("video, audio")) wireElement(node);
          node.querySelectorAll?.("video, audio").forEach(wireElement);
        });
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function engage() {
    ensureContext();
    if (audioContext.state === "suspended") {
      audioContext.resume().catch(() => {});
    }
    document.querySelectorAll("video, audio").forEach(wireElement);
    startObserving();
    engaged = true;
  }

  function setVolume(percent) {
    currentVolume = Math.max(0, percent) / 100;
    engage();
    masterGain.gain.value = currentVolume;
  }

  function applyPreset(name) {
    engage();
    currentPreset = name;
    if (name === "bass") {
      bassFilter.gain.value = 12; // punchy low end
      voiceFilter.gain.value = 0;
    } else if (name === "voice") {
      bassFilter.gain.value = -3; // trim boom
      voiceFilter.gain.value = 8; // lift speech band
    } else {
      bassFilter.gain.value = 0;
      voiceFilter.gain.value = 0;
      currentPreset = "default";
    }
  }

  function getState() {
    return {
      ok: true,
      volume: Math.round(currentVolume * 100),
      preset: currentPreset,
      hasMedia: document.querySelector("video, audio") !== null,
      engaged,
    };
  }

  api.runtime.onMessage.addListener((message) => {
    switch (message?.type) {
      case "get-state":
        return Promise.resolve(getState());
      case "set-volume":
        setVolume(message.value);
        return Promise.resolve(getState());
      case "set-preset":
        applyPreset(message.name);
        return Promise.resolve(getState());
      case "reset":
        applyPreset("default");
        setVolume(100);
        return Promise.resolve(getState());
      default:
        return undefined;
    }
  });
})();
