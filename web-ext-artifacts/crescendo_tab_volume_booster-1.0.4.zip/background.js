// Tab Volume Booster - background (event page).
// Two small jobs, both keyed to a TAB:
//
//   1. The toolbar badge — the number under the icon showing the tab's volume
//      when it's boosted or cut.
//   2. Per-tab memory — so a tab keeps its volume/preset across a refresh.
//
// Both live here because both need the tab id, which a content script can't see
// for itself. Each content script REPORTS its volume+preset to us; we badge its
// tab and stash the values under that tab's id. When the script loads again
// (fresh tab, or after a refresh — a refresh keeps the SAME tab id) it asks us
// to RESTORE, and we hand back whatever that tab last had.
//
// NOTE on the indicator: Firefox draws BADGE text in its own fixed system font,
// so a badge number can't be enlarged — only recoloured. To show a big, readable
// number we instead PAINT it as the whole toolbar icon: a violet tile with the
// percentage filling it edge to edge, so the digits are as tall as the button
// itself (much larger than the corner badge). An earlier custom-icon attempt was
// reverted for being "too small", but that one sat a small number inside the
// icon; filling the tile is what makes it big. At exactly 100% we restore the
// normal logo icon so a tab at normal volume looks untouched.
//
// Storage is storage.session: it lives in memory for the browser session and is
// wiped when the browser closes. That's exactly per-tab semantics — tab ids are
// only meaningful within a session, so a value can never leak onto a reused id
// after a restart.

const api = typeof browser !== "undefined" ? browser : chrome;

const DEFAULT_PERCENT = 100; // at exactly this we show the clean logo icon

// The number-tile icon. Violet to match the popup accent, white number for
// contrast, rendered large then scaled down by the toolbar so it stays crisp.
const TILE_SIZE = 96;
const TILE_BG = "#16a34a"; // green to match the speaker icon (white digits stay legible on it)
const DEFAULT_ICON = { 48: "icons/icon.svg", 96: "icons/icon.svg" };

const keyFor = (tabId) => `tab-${tabId}`;

// Draw the percentage as an icon: a rounded violet tile with the number grown to
// FILL it — bounded by both width and height so the digits are as large as the
// toolbar's fixed icon box physically allows (the real limit is that box; the win
// is using all of it instead of leaving padding, which the first version did).
function numberIcon(percent) {
  const s = TILE_SIZE;
  const ctx = new OffscreenCanvas(s, s).getContext("2d");

  ctx.fillStyle = TILE_BG;
  ctx.beginPath();
  ctx.roundRect(0, 0, s, s, s * 0.22);
  ctx.fill();

  const text = String(percent);
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // Grow the font until the digits just touch the tile — capped by width AND by
  // real glyph height (measureText's bounding box), so "5" fills top-to-bottom
  // and "1200" fills side-to-side, each as big as it can be.
  const maxW = s * 0.92;
  const maxH = s * 0.84;
  let font = s;
  for (; font > 8; font -= 1) {
    ctx.font = `800 ${font}px "Segoe UI", system-ui, sans-serif`;
    const m = ctx.measureText(text);
    const h = m.actualBoundingBoxAscent + m.actualBoundingBoxDescent;
    if (m.width <= maxW && h <= maxH) break;
  }

  ctx.fillText(text, s / 2, s / 2 + s * 0.02);
  return ctx.getImageData(0, 0, s, s);
}

function setIndicator(tabId, percent) {
  if (tabId == null) return;
  // Wrap each call: a tab can vanish (closed/navigated) between the report and
  // here, which rejects the promise — harmless, so swallow it.
  const icon =
    percent === DEFAULT_PERCENT
      ? { tabId, path: DEFAULT_ICON } // back to the clean logo at normal volume
      : { tabId, imageData: { [TILE_SIZE]: numberIcon(percent) } };
  api.action.setIcon(icon).catch(() => {});
}

api.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab?.id;

  if (message?.type === "vol-state") {
    // A tab's volume/preset changed: reflect it on the icon and remember it.
    setIndicator(tabId, message.volume);
    if (tabId != null) {
      api.storage.session
        .set({ [keyFor(tabId)]: { volume: message.volume, preset: message.preset } })
        .catch(() => {});
    }
    return; // no reply needed
  }

  if (message?.type === "vol-restore") {
    // A tab just (re)loaded and wants whatever it had before, if anything.
    if (tabId == null) return Promise.resolve(null);
    return api.storage.session
      .get(keyFor(tabId))
      .then((stored) => stored?.[keyFor(tabId)] ?? null)
      .catch(() => null);
  }

  return undefined;
});

// Tidy up a tab's saved state when it closes (session storage would clear it on
// browser exit anyway; this just keeps it from lingering during the session).
api.tabs.onRemoved.addListener((tabId) => {
  api.storage.session.remove(keyFor(tabId)).catch(() => {});
});
