// Tab Volume Booster - background (event page).
// Two small jobs, both keyed to a TAB:
//
//   1. The toolbar badge — the number under the icon showing the tab's volume
//      when it's boosted or cut.
//   2. Per-tab memory — so a tab keeps its volume/preset across a refresh.
//
// Both live here because both need the tab id, which a content script can't see
// for itself. Each content script REPORTS its volume+preset to us; we badge its
// tab and stash the values under that tab's id. When the script loads again
// (fresh tab, or after a refresh — a refresh keeps the SAME tab id) it asks us
// to RESTORE, and we hand back whatever that tab last had.
//
// NOTE on the indicator: Firefox draws BADGE text in its own fixed system font,
// so a badge number can't be enlarged — only recoloured. To show a big, readable
// number we instead PAINT it as the whole toolbar icon: a violet tile with the
// percentage filling it edge to edge, so the digits are as tall as the button
// itself (much larger than the corner badge). An earlier custom-icon attempt was
// reverted for being "too small", but that one sat a small number inside the
// icon; filling the tile is what makes it big. At exactly 100% we restore the
// normal logo icon so a tab at normal volume looks untouched.
//
// Storage is storage.session: it lives in memory for the browser session and is
// wiped when the browser closes. That's exactly per-tab semantics — tab ids are
// only meaningful within a session, so a value can never leak onto a reused id
// after a restart.

const api = typeof browser !== "undefined" ? browser : chrome;

const DEFAULT_PERCENT = 100; // at exactly this we show the clean logo icon

// The number-tile icon. Violet to match the popup accent, white number for
// contrast, rendered large then scaled down by the toolbar so it stays crisp.
const TILE_SIZE = 96;
const TILE_BG = "#6d5cff";
const DEFAULT_ICON = { 48: "icons/icon.svg", 96: "icons/icon.svg" };

const keyFor = (tabId) => `tab-${tabId}`;

// A faint speaker silhouette drawn as a watermark BEHIND the number, so the tile
// reads as "sound" without touching the digits (they're painted opaque on top).
function drawSpeaker(ctx, s) {
  const d = s * 0.6; // glyph box, centred on the tile
  const o = (s - d) / 2;
  const X = (v) => o + v * d;
  const Y = (v) => o + v * d;

  ctx.save();
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = d * 0.07;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  // Speaker body + cone.
  ctx.beginPath();
  ctx.moveTo(X(0.05), Y(0.38));
  ctx.lineTo(X(0.22), Y(0.38));
  ctx.lineTo(X(0.45), Y(0.18));
  ctx.lineTo(X(0.45), Y(0.82));
  ctx.lineTo(X(0.22), Y(0.62));
  ctx.lineTo(X(0.05), Y(0.62));
  ctx.closePath();
  ctx.fill();

  // Two sound-wave arcs off the cone.
  for (const r of [0.2, 0.34]) {
    ctx.beginPath();
    ctx.arc(X(0.45), Y(0.5), d * r, -Math.PI / 4, Math.PI / 4);
    ctx.stroke();
  }
  ctx.restore();
}

// Draw the percentage as an icon: a rounded violet tile with the number sized to
// fill it — tall for 1–2 digits, shrunk just enough to fit 3–4 (e.g. "1200").
function numberIcon(percent) {
  const s = TILE_SIZE;
  const ctx = new OffscreenCanvas(s, s).getContext("2d");

  ctx.fillStyle = TILE_BG;
  ctx.beginPath();
  ctx.roundRect(0, 0, s, s, s * 0.23);
  ctx.fill();

  drawSpeaker(ctx, s); // watermark behind the digits

  const text = String(percent);
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // Fit the font: start tall, shrink until the digits fit the tile's width.
  const maxW = s * 0.86;
  let font = s * 0.72;
  do {
    ctx.font = `700 ${font}px "Segoe UI", system-ui, sans-serif`;
    if (ctx.measureText(text).width <= maxW) break;
    font -= 2;
  } while (font > 10);

  ctx.fillText(text, s / 2, s / 2 + s * 0.05);
  return ctx.getImageData(0, 0, s, s);
}

function setIndicator(tabId, percent) {
  if (tabId == null) return;
  // Wrap each call: a tab can vanish (closed/navigated) between the report and
  // here, which rejects the promise — harmless, so swallow it.
  const icon =
    percent === DEFAULT_PERCENT
      ? { tabId, path: DEFAULT_ICON } // back to the clean logo at normal volume
      : { tabId, imageData: { [TILE_SIZE]: numberIcon(percent) } };
  api.action.setIcon(icon).catch(() => {});
}

api.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab?.id;

  if (message?.type === "vol-state") {
    // A tab's volume/preset changed: reflect it on the icon and remember it.
    setIndicator(tabId, message.volume);
    if (tabId != null) {
      api.storage.session
        .set({ [keyFor(tabId)]: { volume: message.volume, preset: message.preset } })
        .catch(() => {});
    }
    return; // no reply needed
  }

  if (message?.type === "vol-restore") {
    // A tab just (re)loaded and wants whatever it had before, if anything.
    if (tabId == null) return Promise.resolve(null);
    return api.storage.session
      .get(keyFor(tabId))
      .then((stored) => stored?.[keyFor(tabId)] ?? null)
      .catch(() => null);
  }

  return undefined;
});

// Tidy up a tab's saved state when it closes (session storage would clear it on
// browser exit anyway; this just keeps it from lingering during the session).
api.tabs.onRemoved.addListener((tabId) => {
  api.storage.session.remove(keyFor(tabId)).catch(() => {});
});
